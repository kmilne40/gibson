#!/bin/bash

while true; do
  clear
  echo "=== System Stats ==="
  echo ""

  echo "Disk Usage:"
  df -h --total | awk '/total/ {print $0}'
  echo ""

  echo "CPU Load (1/5/15 min):"
  awk '{print "Load Avg:", $(NF-2), $(NF-1), $NF}' /proc/loadavg
  echo ""

  echo "Memory Usage:"
  mem=$(free -m | awk '/Mem:/ {print $3, $2}')
  used=$(echo $mem | cut -d' ' -f1)
  total=$(echo $mem | cut -d' ' -f2)
  percent=$(awk "BEGIN {printf \"%.1f\", ($used/$total)*100}")
  echo "$used MB used / $total MB total ($percent%)"
  if (( $(echo "$percent > 90.0" | bc -l) )); then
    echo "⚠️ Memory usage is high!"
  fi
  echo ""

  sleep 2
done
