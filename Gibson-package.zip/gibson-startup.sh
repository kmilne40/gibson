#!/bin/bash

# start-Gibson.sh - Launch all Gibson simulator components

echo "Starting Gibson Mainframe Simulator components..."

# Start all services in background
echo "1. Launching main simulator on port 2023..."
python3 gibson-working.py -p 2023 &
sleep 2

echo "2. Starting CICS subsystem..."
python3 CICS.py &
sleep 1

echo "3. Starting FTP server on port 2111..."
python3 gibftpmulti.py --ftp 2111 &
sleep 1

echo "4. Starting DB2 services on ports 50000-50001..."
python3 DB2.py &
sleep 2

echo "5. Launching REST gateway on port 8082..."
python3 zos_rest_gateway.py &
sleep 1

echo "6. Starting vulnerable gateway on port 8081..."
python3 vuln_gateway.py &
sleep 1

# Wait for services to initialize
echo "Waiting for services to initialize..."
sleep 3

# Get and display PIDs
pid_gibson=$(pgrep -f "gibson-working.py")
pid_cics=$(pgrep -f "CICS.py")
pid_ftp=$(pgrep -f "gibftpmulti.py")
pid_db2=$(pgrep -f "DB2.py")
pid_zos=$(pgrep -f "zos_rest_gateway.py")
pid_vuln=$(pgrep -f "vuln_gateway.py")

# Save PIDs for shutdown script
echo "$pid_gibson $pid_cics $pid_ftp $pid_db2 $pid_zos $pid_vuln" > gibson_pids.txt

# Display status
clear
echo "╔════════════════════════════════════════════╗"
echo "║       Gibson Simulator - Running!          ║"
echo "╠════════════════════════╦════════╦═════════╣"
echo "║ Service                ║ Port   ║ PID     ║"
echo "╠════════════════════════╬════════╬═════════╣"
echo "║ Main Simulator         ║ 2023   ║ $pid_gibson ║"
echo "║ CICS                   ║ 2023   ║ $pid_cics ║"
echo "║ FTP Server             ║ 2111   ║ $pid_ftp ║"
echo "║ DB2                    ║ 50000  ║ $pid_db2 ║"
echo "║ REST Gateway           ║ 8082   ║ $pid_zos ║"
echo "║ Vulnerable Gateway     ║ 8081   ║ $pid_vuln ║"
echo "║ Web Dashboard          ║ 8443   ║         ║"
echo "╚════════════════════════╩════════╩═════════╝"
echo ""

# Display connection instructions
echo "To connect:"
echo "1. Main console: ncat 127.0.0.1 2023"
echo "   Login sequence: L TSO → IBMUSER → SYS1"
echo ""
echo "2. Web Dashboard: https://localhost:8443"
echo "   (Credentials in config.json)"
echo ""
echo "3. FTP Access: ftp://localhost:2111"
echo "   (Use IBMUSER/SYS1 for credentials)"
echo ""
echo "Use './gibson-shutdown.sh' to stop all services"
echo ""
echo "Gibson simulator is now ready for mainframe adventures!"
