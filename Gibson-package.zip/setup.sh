#!/bin/bash

# Function to prompt user to continue
prompt_continue() {
    echo ""
    read -p "$1 Press any key to continue..." -n 1 -r
    echo ""
    echo ""
}

# Function to ask yes/no question
ask_question() {
    while true; do
        read -p "$1 (Y/N) " yn
        case $yn in
            [Yy]* ) return 0;;
            [Nn]* ) return 1;;
            * ) echo "Please answer Y or N.";;
        esac
    done
}

# Update system and install dependencies
echo "Updating system and installing dependencies..."
sudo apt update
sudo apt install -y python3 pip nmap hydra ncat c3270 x3270

# Download instructions
prompt_continue "Please use your browser and head to https://offensivesec.org. Click on Gibson in the NavBar and click download for the Gibson Simulator and the Technical Manual."

# Check if unzip is needed (simulated)
if [ ! -d "mfsim" ]; then
    echo "Unzipping Gibson package..."
    unzip Gibson.zip
else
    echo "mfsim directory already exists, skipping unzip"
fi

# Install Python requirements
cd mfsim || exit
echo "Installing Python requirements..."
if ! pip install -r requirements.txt; then
    echo "Trying with --break-system-packages option..."
    pip install -r requirements.txt --break-system-packages
fi

# Ask about starting components
if ask_question "Would you like to start the Gibson components?"; then
    echo "Starting Gibson components in background..."
    python3 gibson-working.py -p 2023 &
    python3 CICS.py &
    python3 gibftpmulti.py --ftp 2111 &
    python3 DB2.py &
    python3 zos_rest_gateway.py &
    python3 vuln_gateway.py &
    
    sleep 3  # Give services time to start
    
    clear
    echo "Scanning for open ports..."
    nmap 127.0.0.1 -p-
    
    echo ""
    echo "Services and their process IDs:"
    echo "+-------------------------+----------------+------------+"
    echo "| Service                 | Port(s)        | PID        |"
    echo "+-------------------------+----------------+------------+"
    
    # Get PIDs and add to table
    pid_gibson=$(pgrep -f "gibson-working.py")
    pid_cics=$(pgrep -f "CICS.py")
    pid_ftp=$(pgrep -f "gibftpmulti.py")
    pid_db2=$(pgrep -f "DB2.py")
    pid_zos=$(pgrep -f "zos_rest_gateway.py")
    pid_vuln=$(pgrep -f "vuln_gateway.py")
    
    echo "| gibson-simulator        | 2023           | $pid_gibson |"
    echo "| gibson ftp server       | 2111           | $pid_ftp |"
    echo "| DB2                     | 50000, 50001   | $pid_db2 |"
    echo "| CICS                    | 2023           | $pid_cics |"
    echo "| zos_rest_gateway        | 8082, 8092     | $pid_zos |"
    echo "| vuln_gateway            | 8081           | $pid_vuln |"
    echo "+-------------------------+----------------+------------+"
    
    # Save PIDs to file for shutdown script
    echo "$pid_gibson $pid_cics $pid_ftp $pid_db2 $pid_zos $pid_vuln" > gibson_pids.txt
    
    prompt_continue "Gibson is up and running! Connect to it with 'ncat 127.0.0.1 2023' then type L TSO (enter) type IBMUSER (enter) and SYS1 (enter). Hit enter at the next screen and you will be at the ready prompt. Have fun!"
else
    echo "Gibson components were not started."
    echo "You can start them manually later using:"
    echo "  python3 gibson-working.py -p 2023 &"
    echo "  python3 CICS.py &"
    echo "  python3 gibftpmulti.py --ftp 2111 &"
    echo "  python3 DB2.py &"
    echo "  python3 zos_rest_gateway.py &"
    echo "  python3 vuln_gateway.py &"
fi
