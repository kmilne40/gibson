#!/bin/bash

echo "Shutting down Gibson services..."

# Check if PID file exists
if [ -f "gibson_pids.txt" ]; then
    # Read PIDs from file
    pids=$(cat gibson_pids.txt)
    
    # Kill each process
    for pid in $pids; do
        if ps -p $pid > /dev/null; then
            echo "Killing process $pid"
            kill $pid
        fi
    done
    
    # Remove PID file
    rm gibson_pids.txt
    echo "All Gibson services have been stopped."
else
    echo "No Gibson processes found (gibson_pids.txt missing)."
    echo "Trying to find and kill processes manually..."
    
    # Fallback method if PID file is missing
    pids=$(pgrep -f "python3 .*(gibson-working.py|CICS.py|gibftpmulti.py|DB2.py|zos_rest_gateway.py|vuln_gateway.py)")
    
    if [ -z "$pids" ]; then
        echo "No Gibson processes found."
    else
        for pid in $pids; do
            echo "Killing process $pid"
            kill $pid
        done
        echo "All Gibson services have been stopped."
    fi
fi
