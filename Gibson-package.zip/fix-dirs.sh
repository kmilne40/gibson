#!/bin/sh
set -eu

for udir in /home/user[0-9]*; do
  [ -d "$udir" ] || continue
  dest="$udir/mfcourse"
  [ -d "$dest" ] || continue

  # Find a nested "mfcourse" under $dest (e.g., $dest/home/*/mfcourse)
  nested=$(find "$dest" -type d -name mfcourse ! -path "$dest" 2>/dev/null | head -n 1 || true)
  [ -n "${nested:-}" ] || { echo "No nested mfcourse under $dest — skipping"; continue; }

  echo "Flattening: $nested -> $dest"

  if command -v rsync >/dev/null 2>&1; then
    # Move contents (incl. dotfiles) up one level, remove sources
    rsync -a --remove-source-files "$nested"/ "$dest"/
    # Remove now-empty tree under $dest/home/...
    find "$dest" -type d -empty -delete 2>/dev/null || true
  else
    # Fallback: copy via tar, then remove the specific nested tree if empty
    (cd "$nested" && tar cf - .) | (cd "$dest" && tar xpf -)
    # Try to remove the nested path and its parents if now empty
    rmdir "$nested" 2>/dev/null || true
    parent=$(dirname "$nested"); rmdir "$parent" 2>/dev/null || true
    grand=$(dirname "$parent"); rmdir "$grand" 2>/dev/null || true
  fi

  # Ensure ownership back to the user
  user=$(basename "$udir")
  chown -R "$user:$user" "$dest" 2>/dev/null || true
done
