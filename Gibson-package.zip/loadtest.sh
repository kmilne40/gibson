#!/usr/bin/env bash
# loadtest.sh — Linux server load test with live dashboard
# Workloads: Firefox->http://localhost:8000, John the Ripper self-test, nmap (localhost), telnet 192.168.0.202:2023, optional RDP
# Author: ChatGPT for Kev
set -euo pipefail

# ---------- Defaults ----------
USERS=15
DURATION=300                              # seconds
FIREFOX_URL="http://localhost:8000"
ENABLE_RDP=0
NET_IFACE="auto"                          # or explicit: eth0, ens3, ...
CSV_OUT="loadtest_metrics.csv"
LOG_FILE="loadtest.log"

# Workloads
NMAP_TARGET="127.0.0.1"
TELNET_HOST="192.168.0.202"
TELNET_PORT=2023

# Shares (weights) across USERS (random assignment)
BROWSER_SHARE=1
JOHN_SHARE=1
NMAP_SHARE=1
TELNET_SHARE=1
RDP_SHARE=1

# UI/Logging
DASHBOARD=1                               # live TUI on by default
QUIET_LOGS=1                              # send logs to file so TUI stays clean
NET_BAR_WIDTH=40                          # width of RX/TX bars
CPU_BAR_WIDTH=40

# ---------- Args ----------
usage() {
  cat <<EOF
Usage: $0 [--users N] [--duration SEC] [--iface IFACE|auto]
         [--firefox-url URL] [--nmap-target HOST]
         [--telnet-host HOST] [--telnet-port PORT]
         [--enable-rdp] [--no-browser] [--no-john] [--no-nmap] [--no-telnet] [--no-rdp]
         [--no-dashboard] [--verbose-logs]

Examples:
  sudo $0 --users 15 --duration 300 --enable-rdp

Notes:
  - Browser hits: default ${FIREFOX_URL}
  - Telnet worker: ${TELNET_HOST}:${TELNET_PORT}
  - nmap target: ${NMAP_TARGET}
  - Metrics -> ${CSV_OUT}; Logs -> ${LOG_FILE}
EOF
  exit 1
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --users) USERS="${2:-}"; shift 2 ;;
    --duration) DURATION="${2:-}"; shift 2 ;;
    --iface) NET_IFACE="${2:-}"; shift 2 ;;
    --firefox-url) FIREFOX_URL="${2:-}"; shift 2 ;;
    --nmap-target) NMAP_TARGET="${2:-}"; shift 2 ;;
    --telnet-host) TELNET_HOST="${2:-}"; shift 2 ;;
    --telnet-port) TELNET_PORT="${2:-}"; shift 2 ;;
    --enable-rdp) ENABLE_RDP=1; shift 1 ;;
    --no-browser) BROWSER_SHARE=0; shift 1 ;;
    --no-john) JOHN_SHARE=0; shift 1 ;;
    --no-nmap) NMAP_SHARE=0; shift 1 ;;
    --no-telnet) TELNET_SHARE=0; shift 1 ;;
    --no-rdp) RDP_SHARE=0; ENABLE_RDP=0; shift 1 ;;
    --no-dashboard) DASHBOARD=0; shift 1 ;;
    --verbose-logs) QUIET_LOGS=0; shift 1 ;;
    -h|--help) usage ;;
    *) echo "Unknown arg: $1"; usage ;;
  esac
done

# ---------- Helpers ----------
have() { command -v "$1" >/dev/null 2>&1; }

log() {
  local line="[$(date +'%F %T')] $*"
  if (( QUIET_LOGS )); then
    echo "$line" >> "$LOG_FILE"
  else
    echo -e "$line"
  fi
}

cleanup_pids=()
restore_terminal() {
  if (( DASHBOARD )); then
    tput cnorm 2>/dev/null || true
    stty echo 2>/dev/null || true
  fi
}
cleanup() {
  log "Stopping workers..."
  for p in "${cleanup_pids[@]:-}"; do
    if kill -0 "$p" 2>/dev/null; then kill "$p" 2>/dev/null || true; fi
  done
  wait || true
  restore_terminal
}
trap cleanup EXIT INT TERM

# Auto-detect primary interface
detect_iface() {
  local cand=""
  if [[ "$NET_IFACE" != "auto" ]]; then echo "$NET_IFACE"; return 0; fi
  if have ip; then
    cand=$(ip -o route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}' || true)
  fi
  if [[ -z "$cand" ]]; then
    cand=$(awk -F: '/:/ {gsub(/ /,""); iface=$1; if (iface!="lo") {print iface; exit}}' /proc/net/dev || true)
  fi
  [[ -z "$cand" ]] && cand="lo"
  echo "$cand"
}
PRIMARY_IFACE=$(detect_iface)

# CPU + NET readers
read_cpu_totals() {
  # fields: user nice system idle iowait irq softirq steal guest guest_nice
  awk '/^cpu /{
    total=$2+$3+$4+$5+$6+$7+$8+$9+$10+$11;
    idle=$5+$6;
    printf "%.0f %.0f\n", total, idle
  }' /proc/stat
}
read_iface_bytes() {
  local iface="$1"
  awk -v i="${iface}:" '$1==i{rx=$2; tx=$10; printf "%.0f %.0f\n", rx, tx; exit}' /proc/net/dev
}
read_loadavg() { awk '{printf "%s %s %s", $1,$2,$3}' /proc/loadavg; }

# Bars
make_bar() { # pct width
  local pct="$1" width="$2"
  local filled=$(awk -v p="$pct" -v w="$width" 'BEGIN{v=int((p/100)*w); if(v>w) v=w; print v}')
  local empty=$(( width - filled ))
  printf "[%s%s]" "$(head -c "$filled" < /dev/zero | tr '\0' '#')" "$(head -c "$empty" < /dev/zero | tr '\0' ' ')"
}
make_rel_bar() { # value max width
  local val="$1" max="$2" width="$3"
  if awk -v m="$max" 'BEGIN{exit (m<=0)}'; then
    printf "[%s]" "$(head -c "$width" < /dev/zero | tr '\0' ' ')"
    return
  fi
  local filled=$(awk -v v="$val" -v m="$max" -v w="$width" 'BEGIN{p=v/m; if(p>1)p=1; print int(p*w)}')
  local empty=$(( width - filled ))
  printf "[%s%s]" "$(head -c "$filled" < /dev/zero | tr '\0' '=')" "$(head -c "$empty" < /dev/zero | tr '\0' ' ')"
}

# ---------- Dashboard ----------
draw_dashboard() {
  local now_iso="$1" elapsed="$2" remain="$3" cpu_pct="$4" rx="$5" tx="$6" \
        avg_cpu="$7" peak_cpu="$8" avg_rx="$9" peak_rx="${10}" avg_tx="${11}" peak_tx="${12}" \
        load1="${13}" load5="${14}" load15="${15}" mix_line="${16}" max_rx_sofar="${17}" max_tx_sofar="${18}"

  # Clear + home
  printf "\033[2J\033[H"

  # Header
  echo "Load Test Dashboard (iface: ${PRIMARY_IFACE})    ${now_iso}"
  echo "Duration: ${DURATION}s | Elapsed: ${elapsed}s | Remaining: ${remain}s"
  # Progress bar
  local prog_width=50
  local prog_fill=$(awk -v e="$elapsed" -v d="$DURATION" -v w="$prog_width" 'BEGIN{p=e/d; if(p>1)p=1; print int(p*w)}')
  printf "Progress: ["
  printf "%0.s#" $(seq 1 "$prog_fill")
  printf "%0.s " $(seq 1 $((prog_width - prog_fill)))
  printf "] %s%%\n" "$(awk -v e="$elapsed" -v d="$DURATION" 'BEGIN{printf "%.0f", (e/d)*100}')"

  echo

  # CPU
  printf "CPU:  %6.2f%% " "$cpu_pct"; make_bar "$cpu_pct" "$CPU_BAR_WIDTH"; printf "  avg:%6.2f%%  peak:%6.2f%%  load:%s %s %s\n" "$avg_cpu" "$peak_cpu" "$load1" "$load5" "$load15"

  # NET
  local total_rx_max="$max_rx_sofar"
  local total_tx_max="$max_tx_sofar"
  printf "RX:  %9.2f kbps " "$rx"; make_rel_bar "$rx" "$total_rx_max" "$NET_BAR_WIDTH"; printf "  avg:%9.2f  peak:%9.2f\n" "$avg_rx" "$peak_rx"
  printf "TX:  %9.2f kbps " "$tx"; make_rel_bar "$tx" "$total_tx_max" "$NET_BAR_WIDTH"; printf "  avg:%9.2f  peak:%9.2f\n" "$avg_tx" "$peak_tx"

  echo
  echo "Workers: ${mix_line}"
  echo "Logs: ${LOG_FILE}   CSV: ${CSV_OUT}"
  echo "(Ctrl+C to stop)"
}

# ---------- Monitoring loop (CSV + Dashboard) ----------
monitor() {
  [[ -f "$CSV_OUT" ]] && : > "$CSV_OUT"
  echo "timestamp,epoch,cpu_pct,rx_kbps,tx_kbps" > "$CSV_OUT"

  read -r pt pi < <(read_cpu_totals)
  read -r prx ptx < <(read_iface_bytes "$PRIMARY_IFACE")
  local start_ts=$(date +%s)

  # stats so far
  local n=0 sum_cpu=0 sum_rx=0 sum_tx=0 peak_cpu=0 peak_rx=0 peak_tx=0
  local max_rx_sofar=1 max_tx_sofar=1

  if (( DASHBOARD )); then
    tput civis 2>/dev/null || true
    stty -echo 2>/dev/null || true
    log "Dashboard active; suppressing noisy logs. See ${LOG_FILE}."
  fi

  while :; do
    sleep 1
    read -r ct ci < <(read_cpu_totals)
    read -r crx ctx < <(read_iface_bytes "$PRIMARY_IFACE")

    local dt=$((ct - pt)); local didle=$((ci - pi))
    local cpu_pct=0
    (( dt > 0 )) && cpu_pct=$(awk -v dt="$dt" -v didle="$didle" 'BEGIN{printf "%.2f", (1 - (didle/dt))*100}')
    local drx=$((crx - prx)); local dtx=$((ctx - ptx))
    local rx_kbps=$(awk -v b="$drx" 'BEGIN{printf "%.2f", (b*8)/1000}')
    local tx_kbps=$(awk -v b="$dtx" 'BEGIN{printf "%.2f", (b*8)/1000}')
    local now_iso=$(date -Iseconds); local now_epoch=$(date +%s)

    echo "${now_iso},${now_epoch},${cpu_pct},${rx_kbps},${tx_kbps}" >> "$CSV_OUT"

    # update accumulators
    n=$((n+1))
    sum_cpu=$(awk -v s="$sum_cpu" -v v="$cpu_pct" 'BEGIN{printf "%.6f", s+v}')
    sum_rx=$(awk -v s="$sum_rx" -v v="$rx_kbps" 'BEGIN{printf "%.6f", s+v}')
    sum_tx=$(awk -v s="$sum_tx" -v v="$tx_kbps" 'BEGIN{printf "%.6f", s+v}')
    peak_cpu=$(awk -v p="$peak_cpu" -v v="$cpu_pct" 'BEGIN{printf "%.2f", (v>p)?v:p}')
    peak_rx=$(awk -v p="$peak_rx" -v v="$rx_kbps" 'BEGIN{printf "%.2f", (v>p)?v:p}')
    peak_tx=$(awk -v p="$peak_tx" -v v="$tx_kbps" 'BEGIN{printf "%.2f", (v>p)?v:p}')
    max_rx_sofar=$(awk -v m="$max_rx_sofar" -v v="$rx_kbps" 'BEGIN{printf "%.2f", (v>m)?v:m}')
    max_tx_sofar=$(awk -v m="$max_tx_sofar" -v v="$tx_kbps" 'BEGIN{printf "%.2f", (v>m)?v:m}')

    local avg_cpu=$(awk -v s="$sum_cpu" -v nn="$n" 'BEGIN{printf "%.2f", (nn>0)?s/nn:0}')
    local avg_rx=$(awk -v s="$sum_rx" -v nn="$n" 'BEGIN{printf "%.2f", (nn>0)?s/nn:0}')
    local avg_tx=$(awk -v s="$sum_tx" -v nn="$n" 'BEGIN{printf "%.2f", (nn>0)?s/nn:0}')

    if (( DASHBOARD )); then
      read -r load1 load5 load15 < <(read_loadavg)
      local elapsed=$(( now_epoch - start_ts ))
      local remain=$(( DURATION - elapsed )); (( remain < 0 )) && remain=0
      draw_dashboard "$now_iso" "$elapsed" "$remain" "$cpu_pct" "$rx_kbps" "$tx_kbps" \
                     "$avg_cpu" "$peak_cpu" "$avg_rx" "$peak_rx" "$avg_tx" "$peak_tx" \
                     "$load1" "$load5" "$load15" "$MIX_LINE" "$max_rx_sofar" "$max_tx_sofar"
    fi

    pt=$ct; pi=$ci; prx=$crx; ptx=$ctx
    (( now_epoch - start_ts >= DURATION )) && break
  done
}

# ---------- Workers ----------
browser_worker() {
  local idx="$1"; local until=$(( $(date +%s) + DURATION ))
  local url="${FIREFOX_URL}"
  log "[BROWSER $idx] Firefox headless hits to ${url}"
  if have firefox; then
    while (( $(date +%s) < until )); do
      timeout 15s firefox --headless --private-window --screenshot "${url}" >/dev/null 2>&1 || true
      sleep 1
    done
  else
    log "[BROWSER $idx] firefox not found; using curl"
    while (( $(date +%s) < until )); do
      curl -m 10 -fsS "${url}" -o /dev/null || true
      sleep 1
    done
  fi
}

john_worker() {
  local idx="$1"; local until=$(( $(date +%s) + DURATION ))
  log "[JOHN $idx] john --test load"
  if have john; then
    if john --test --format=md5crypt --max-run-time=5 >/dev/null 2>&1; then
      while (( $(date +%s) < until )); do
        OMP_NUM_THREADS=1 john --test --format=md5crypt --max-run-time=10 >/dev/null 2>&1 || true
      done
    else
      while (( $(date +%s) < until )); do
        OMP_NUM_THREADS=1 john --test=10 >/dev/null 2>&1 || true
      done
    fi
  else
    log "[JOHN $idx] john not found; CPU load via openssl"
    if have openssl; then
      while (( $(date +%s) < until )); do
        timeout 10s openssl enc -aes-256-cbc -k secret -in /dev/zero -out /dev/null >/dev/null 2>&1 || true
      done
    else
      local end=$until; while (( $(date +%s) < end )); do :; done
    fi
  fi
}

nmap_worker() {
  local idx="$1"; local until=$(( $(date +%s) + DURATION ))
  log "[NMAP $idx] nmap scans against ${NMAP_TARGET}"
  if have nmap; then
    while (( $(date +%s) < until )); do
      nmap -T4 -F "${NMAP_TARGET}" >/dev/null 2>&1 || true
    done
  else
    log "[NMAP $idx] nmap not found; simulating TCP chatter to ${NMAP_TARGET}:80"
    while (( $(date +%s) < until )); do
      dd if=/dev/zero bs=16k count=64 2>/dev/null | nc -N -w 5 "${NMAP_TARGET}" 80 >/dev/null 2>&1 || true
      sleep 1
    done
  fi
}

telnet_worker() {
  local idx="$1"; local until=$(( $(date +%s) + DURATION ))
  local host="${TELNET_HOST}"; local port="${TELNET_PORT}"
  log "[TELNET $idx] TCP sessions to ${host}:${port}"
  while (( $(date +%s) < until )); do
    if have telnet; then
      printf "echo test-$RANDOM\r\n" | timeout 10s telnet "${host}" "${port}" >/dev/null 2>&1 || true
    elif have nc; then
      printf "echo test-$RANDOM\n" | timeout 10s nc -w 5 "${host}" "${port}" >/dev/null 2>&1 || true
    elif have ncat; then
      printf "echo test-$RANDOM\n" | timeout 10s ncat --send-only "${host}" "${port}" >/dev/null 2>&1 || true
    else
      { exec 3<>"/dev/tcp/${host}/${port}" || exit 1
        printf "echo test-$RANDOM\r\n" >&3 || true
        ( timeout 2s cat <&3 >/dev/null 2>&1 || true )
        exec 3>&- 3<&-
      } || true
    fi
    sleep 0.5
  done
}

rdp_worker() {
  local idx="$1"; local until=$(( $(date +%s) + DURATION ))
  if [[ "${ENABLE_RDP}" -ne 1 ]]; then log "[RDP $idx] disabled."; return 0; fi
  if ! have xfreerdp; then log "[RDP $idx] xfreerdp not installed; skipping."; return 0; fi
  if ! systemctl is-active --quiet xrdp; then log "[RDP $idx] xrdp not active; skipping."; return 0; fi
  if [[ -z "${RDP_USER:-}" || -z "${RDP_PASS:-}" ]]; then log "[RDP $idx] RDP_USER/RDP_PASS not set; skipping."; return 0; fi
  local base_cmd=(xfreerdp /v:127.0.0.1 /u:"${RDP_USER}" /p:"${RDP_PASS}" /cert:ignore /auto-reconnect /network:auto /log-level:ERROR +clipboard /gfx)
  log "[RDP $idx] opening local RDP session as ${RDP_USER}"
  if have xvfb-run; then
    timeout "${DURATION}s" xvfb-run -a "${base_cmd[@]}" >/dev/null 2>&1 || true
  else
    timeout "${DURATION}s" "${base_cmd[@]}" >/dev/null 2>&1 || true
  fi
}

# ---------- Task distribution ----------
sum_shares=$(( BROWSER_SHARE + JOHN_SHARE + NMAP_SHARE + TELNET_SHARE + (ENABLE_RDP*RDP_SHARE) ))
if (( sum_shares == 0 )); then echo "All task types disabled; nothing to do."; exit 1; fi

assignments=()
count_browser=0; count_john=0; count_nmap=0; count_telnet=0; count_rdp=0
for ((i=0; i<USERS; i++)); do
  r=$(( RANDOM % sum_shares ))
  cursor=0
  if (( BROWSER_SHARE > 0 )); then
    (( cursor += BROWSER_SHARE )); if (( r < cursor )); then assignments+=("browser"); ((count_browser++)); continue; fi
  fi
  if (( JOHN_SHARE > 0 )); then
    (( cursor += JOHN_SHARE )); if (( r < cursor )); then assignments+=("john"); ((count_john++)); continue; fi
  fi
  if (( NMAP_SHARE > 0 )); then
    (( cursor += NMAP_SHARE )); if (( r < cursor )); then assignments+=("nmap"); ((count_nmap++)); continue; fi
  fi
  if (( TELNET_SHARE > 0 )); then
    (( cursor += TELNET_SHARE )); if (( r < cursor )); then assignments+=("telnet"); ((count_telnet++)); continue; fi
  fi
  if (( ENABLE_RDP == 1 && RDP_SHARE > 0 )); then assignments+=("rdp"); ((count_rdp++)); continue; fi
  assignments+=("browser"); ((count_browser++))
done

MIX_LINE="browser:${count_browser}  john:${count_john}  nmap:${count_nmap}  telnet:${count_telnet}  rdp:${count_rdp}"
log "Planned assignments: ${MIX_LINE}"
echo "Using network interface: ${PRIMARY_IFACE}"

# ---------- Launch ----------
monitor & cleanup_pids+=($!)
sleep 1

for i in "${!assignments[@]}"; do
  kind="${assignments[$i]}"
  case "$kind" in
    browser) browser_worker "$i" & ;;
    john)    john_worker "$i" & ;;
    nmap)    nmap_worker "$i" & ;;
    telnet)  telnet_worker "$i" & ;;
    rdp)     rdp_worker "$i" & ;;
    *)       browser_worker "$i" & ;;
  esac
  cleanup_pids+=($!)
done

# Wait for all workers and monitor
wait

# ---------- Final summary ----------
if [[ -s "$CSV_OUT" ]]; then
  avg_cpu=$(awk -F, 'NR>1{sum+=$3; n++} END{if(n) printf "%.2f", sum/n; else print "0.00"}' "$CSV_OUT")
  peak_cpu=$(awk -F, 'NR>1{if($3>p) p=$3} END{printf "%.2f", p+0}' "$CSV_OUT")
  avg_rx=$(awk -F, 'NR>1{sum+=$4; n++} END{if(n) printf "%.2f", sum/n; else print "0.00"}' "$CSV_OUT")
  peak_rx=$(awk -F, 'NR>1{if($4>p) p=$4} END{printf "%.2f", p+0}' "$CSV_OUT")
  avg_tx=$(awk -F, 'NR>1{sum+=$5; n++} END{if(n) printf "%.2f", sum/n; else print "0.00"}' "$CSV_OUT")
  peak_tx=$(awk -F, 'NR>1{if($5>p) p=$5} END{printf "%.2f", p+0}' "$CSV_OUT")

  [[ $DASHBOARD -eq 1 ]] && printf "\033[2J\033[H" || true
  echo "===== SUMMARY ====="
  echo "Users:            ${USERS}"
  echo "Duration (s):     ${DURATION}"
  echo "Interface:        ${PRIMARY_IFACE}"
  echo "Worker mix:       ${MIX_LINE}"
  echo "Avg CPU (%):      ${avg_cpu}"
  echo "Peak CPU (%):     ${peak_cpu}"
  echo "Avg RX (kbps):    ${avg_rx}"
  echo "Peak RX (kbps):   ${peak_rx}"
  echo "Avg TX (kbps):    ${avg_tx}"
  echo "Peak TX (kbps):   ${peak_tx}"
  echo "Metrics CSV:      ${CSV_OUT}"
  echo "Logs:             ${LOG_FILE}"
  echo "===================="
else
  echo "No metrics written; something went wrong."
fi
