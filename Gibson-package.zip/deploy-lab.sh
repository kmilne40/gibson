#!/bin/sh
# Ubuntu multi-user lab deployer (POSIX /bin/sh version)
# - dialog menu
# - Deploy users userX with default password ubuntu22 (+ sudo)
# - IceWM minimal config: no wallpaper, trimmed taskbar/toolbar, custom menu (X3270, Firefox, Konsole, Terminator, Logout)
# - XRDP + SSH (lean settings)
# - Deploy mfcourse.zip (idempotent)
# - Install packages: nmap, ncat, x3270, firefox, konsole, terminator, xterm
# - Install system-wide requirements.txt for Python 3.10.x
# - Lightweight web server: Python http.server serving /srv via systemd unit (configure/start/stop/status)
# - Logging to /var/log/user_deploy.log

set -eu
umask 022

LOG_FILE="/var/log/user_deploy.log"
: > "$LOG_FILE" 2>/dev/null || touch "$LOG_FILE"
chmod 0644 "$LOG_FILE" 2>/dev/null || true

DIALOG=${DIALOG:-dialog}
BACKTITLE="Ubuntu Lab Deployer (sh)"

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname "$0")" 2>/dev/null && pwd || echo ".")
ZIP_PATH_DEFAULT="$SCRIPT_DIR/mfcourse.zip"
REQS_PATH_DEFAULT="$SCRIPT_DIR/requirements.txt"

DEFAULT_TERM="xterm"
if command -v uxterm >/dev/null 2>&1; then DEFAULT_TERM="uxterm"; fi

APT_UPDATED=0

log() { printf "[%s] %s\n" "$(date '+%F %T%z')" "$*" >>"$LOG_FILE"; }

require_root() {
  if [ "$(id -u)" -ne 0 ]; then
    echo "Please run as root." >&2
    exit 1
  fi
}

apt_ensure() {
  if [ "$APT_UPDATED" -eq 0 ]; then
    log "apt-get update"
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -y >>"$LOG_FILE" 2>&1
    APT_UPDATED=1
  fi
  if [ "$#" -gt 0 ]; then
    log "apt-get install -y $*"
    export DEBIAN_FRONTEND=noninteractive
    apt-get install -y "$@" >>"$LOG_FILE" 2>&1
  fi
}

ensure_dialog() {
  if ! command -v "$DIALOG" >/dev/null 2>&1; then
    echo "[INFO] Installing 'dialog' to display the menu..."
    apt_ensure dialog
  fi
}

get_home() { getent passwd "$1" | awk -F: '{print $6}'; }

# -------------------------------
# IceWM configuration (per-user) - lean + custom menu/toolbar
# -------------------------------
configure_icewm_for_user() {
  USERNAME="$1"
  HOME_DIR=$(get_home "$USERNAME")
  [ -d "$HOME_DIR" ] || return 0

  log "Configuring IceWM for $USERNAME at $HOME_DIR"
  mkdir -p "$HOME_DIR/.icewm"

  # Preferences: trim taskbar applets; keep menu + logout; set terminal
  cat > "$HOME_DIR/.icewm/preferences" <<EOF
UseCompositing=0
TaskBarShowShowDesktop=0
TaskBarShowCPUStatus=0
TaskBarShowNetStatus=0
TaskBarShowMemStatus=0
TaskBarShowAPMStatus=0
TaskBarShowWindowListMenu=1
ShowProgramsMenu=1
ShowLogoutMenu=1
# Keep tray minimal or hide if you prefer: 0 hides it
TaskBarShowTray=0
TaskBarShowClock=1
TerminalCommand="$DEFAULT_TERM"
EOF

  # Minimal startup: solid background color; do NOT start icewmbg or extras
  cat > "$HOME_DIR/.icewm/startup" <<'EOF'
#!/bin/sh
# Lean startup; no icewmbg (no wallpaper), just set a solid color.
if command -v xsetroot >/dev/null 2>&1; then
  xsetroot -solid "#202020"
fi
exit 0
EOF
  chmod +x "$HOME_DIR/.icewm/startup"

  # Custom minimal menu
  cat > "$HOME_DIR/.icewm/menu" <<'EOF'
menu "Applications" "" {
  prog "X3270" "" x3270
  prog "Firefox" "" firefox
  prog "Konsole" "" konsole
  prog "Terminator" "" terminator
  separator
  prog "Logout" "" icesh logout
}
EOF

  # Trim quick-launch toolbar to the essentials
  cat > "$HOME_DIR/.icewm/toolbar" <<'EOF'
prog "X3270" "" x3270
prog "Firefox" "" firefox
prog "Konsole" "" konsole
prog "Terminator" "" terminator
EOF

  # Ensure IceWM session startup
  echo 'exec icewm-session' > "$HOME_DIR/.xsession"

  chown -R "$USERNAME:$USERNAME" "$HOME_DIR/.icewm" "$HOME_DIR/.xsession" 2>/dev/null || true
  chmod 700 "$HOME_DIR" 2>/dev/null || true
}

install_icewm_minimal() {
  apt_ensure icewm xterm x11-xserver-utils
  mkdir -p /etc/skel/.icewm
  cat > /etc/skel/.icewm/preferences <<EOF
UseCompositing=0
TaskBarShowTray=0
ShowProgramsMenu=1
ShowLogoutMenu=1
TerminalCommand="$DEFAULT_TERM"
EOF
  cat > /etc/skel/.icewm/startup <<'EOF'
#!/bin/sh
if command -v xsetroot >/dev/null 2>&1; then
  xsetroot -solid "#202020"
fi
exit 0
EOF
  chmod +x /etc/skel/.icewm/startup
  cat > /etc/skel/.icewm/menu <<'EOF'
menu "Applications" "" {
  prog "X3270" "" x3270
  prog "Firefox" "" firefox
  prog "Konsole" "" konsole
  prog "Terminator" "" terminator
  separator
  prog "Logout" "" icesh logout
}
EOF
  cat > /etc/skel/.icewm/toolbar <<'EOF'
prog "X3270" "" x3270
prog "Firefox" "" firefox
prog "Konsole" "" konsole
prog "Terminator" "" terminator
EOF
  echo 'exec icewm-session' > /etc/skel/.xsession
  log "IceWM defaults written to /etc/skel"
}

# -------------------------------
# sudoers management
# -------------------------------
ensure_sudoers_rule() {
  apt_ensure sudo
  if grep -Eq '^[[:space:]]*%sudo[[:space:]]+ALL=\(ALL:ALL\)[[:space:]]+ALL' /etc/sudoers /etc/sudoers.d/* 2>/dev/null; then
    log "sudoers: %sudo rule already present"
    return 0
  fi
  DROP="/etc/sudoers.d/90-sudo-group"
  log "sudoers: adding %sudo rule via $DROP"
  printf '%%sudo ALL=(ALL:ALL) ALL\n' > "$DROP"
  chmod 0440 "$DROP"
  if visudo -cf /etc/sudoers >>"$LOG_FILE" 2>&1; then
    log "sudoers validated"
  else
    log "sudoers validation FAILED, reverting"
    rm -f "$DROP"
    "$DIALOG" --backtitle "$BACKTITLE" --title "sudoers error" \
      --msgbox "Could not validate /etc/sudoers after adding %sudo rule. Reverted.\nSee $LOG_FILE." 9 70
    return 1
  fi
}

grant_sudo_all_userx() {
  ensure_sudoers_rule
  USERS=$(getent passwd | awk -F: '/^user[0-9]+:/{print $1}')
  if [ -z "${USERS:-}" ]; then
    "$DIALOG" --backtitle "$BACKTITLE" --title "No Users" \
      --msgbox "No userX accounts found." 7 50
    return 0
  fi
  for U in $USERS; do
    log "Adding $U to sudo group"
    usermod -aG sudo "$U" >>"$LOG_FILE" 2>&1 || true
  done
  "$DIALOG" --backtitle "$BACKTITLE" --title "Sudo Access" \
    --msgbox "All userX accounts are now in the sudo group." 8 60
}

# -------------------------------
# User Deployment
# -------------------------------
deploy_users() {
  DEFAULT_COUNT="15"
  COUNT=$("$DIALOG" --backtitle "$BACKTITLE" --title "Deploy Users" --stdout \
          --inputbox "Number of users to create (prefix userX):" 10 60 "$DEFAULT_COUNT") || {
    log "Deploy Users: cancelled"; return 0; }

  case "$COUNT" in
    ''|*[!0-9]*|0) "$DIALOG" --backtitle "$BACKTITLE" --title "Invalid Input" \
         --msgbox "Please enter a positive integer." 8 50; return 1 ;;
  esac

  apt_ensure adduser passwd

  I=1
  while [ "$I" -le "$COUNT" ]; do
    USERNAME="user$I"
    if id -u "$USERNAME" >/dev/null 2>&1; then
      log "User $USERNAME exists; ensuring home and IceWM config"
      HOME_DIR=$(get_home "$USERNAME")
      [ -d "$HOME_DIR" ] || mkdir -p "$HOME_DIR"
      chown -R "$USERNAME:$USERNAME" "$HOME_DIR" 2>/dev/null || true
      chmod 700 "$HOME_DIR" 2>/dev/null || true
    else
      log "Creating $USERNAME"
      adduser --disabled-password --gecos "" "$USERNAME" >>"$LOG_FILE" 2>&1
      echo "$USERNAME:ubuntu22" | chpasswd >>"$LOG_FILE" 2>&1
      passwd -w 0 -x 99999 "$USERNAME" >>"$LOG_FILE" 2>&1 || true
      HOME_DIR=$(get_home "$USERNAME")
      chmod 700 "$HOME_DIR" 2>/dev/null || true
    fi
    configure_icewm_for_user "$USERNAME"
    ensure_sudoers_rule
    usermod -aG sudo "$USERNAME" >>"$LOG_FILE" 2>&1 || true
    I=$((I+1))
  done

  "$DIALOG" --backtitle "$BACKTITLE" --title "Deploy Users" \
    --msgbox "Created/updated users user1..user${COUNT}.\nDefault password: ubuntu22\nAll added to 'sudo' group." 11 60
}

# -------------------------------
# XRDP & SSH (lean)
# -------------------------------
configure_xrdp_ssh() {
  apt_ensure xrdp xorgxrdp openssh-server
  usermod -aG ssl-cert xrdp >>"$LOG_FILE" 2>&1 || true

  if [ -f /etc/xrdp/xrdp.ini ]; then
    sed -i 's/^max_bpp=.*/max_bpp=16/' /etc/xrdp/xrdp.ini || true
    sed -i 's/^bitmap_compression=.*/bitmap_compression=true/' /etc/xrdp/xrdp.ini || true
    # Optionally trim redirection channels for efficiency (leave clipboard enabled by default):
    if grep -q '^\[Channels\]' /etc/xrdp/xrdp.ini; then
      sed -i 's/^\s*rdpdr=.*/rdpdr=false/' /etc/xrdp/xrdp.ini || true   # drives/printers
      # To disable clipboard too, uncomment the next line:
      # sed -i 's/^\s*cliprdr=.*/cliprdr=false/' /etc/xrdp/xrdp.ini || true
    fi
    if ! grep -qs '^\[Xorg\]' /etc/xrdp/xrdp.ini; then
      cat >> /etc/xrdp/xrdp.ini <<'EOF'

[Xorg]
name=Xorg
lib=libxup.so
username=ask
password=ask
ip=127.0.0.1
port=-1
code=20
EOF
    fi
  fi

  if [ -f /etc/xrdp/startwm.sh ]; then
    if ! grep -qs '/etc/X11/Xsession' /etc/xrdp/startwm.sh; then
      printf '\n# Ensure Xsession is used (respects ~/.xsession)\nif [ -r /etc/X11/Xsession ]; then\n  exec /bin/sh /etc/X11/Xsession\nfi\n' >> /etc/xrdp/startwm.sh
    fi
  fi

  systemctl enable --now xrdp >>"$LOG_FILE" 2>&1 || true
  systemctl enable --now ssh >>"$LOG_FILE" 2>&1 || true

  "$DIALOG" --backtitle "$BACKTITLE" --title "XRDP & SSH" \
    --msgbox "XRDP and SSH installed/enabled.\nIceWM starts via ~/.xsession.\n(Clipboard stays ON, drive redirection OFF.)" 11 70
}

# -------------------------------
# Tool Deployment (mfcourse.zip)
# -------------------------------
deploy_mfcourse() {
  ZIP_PATH=$("$DIALOG" --backtitle "$BACKTITLE" --title "mfcourse.zip" --stdout \
             --inputbox "Path to mfcourse.zip" 10 70 "$ZIP_PATH_DEFAULT") || {
    log "Deploy mfcourse: cancelled"; return 0; }
  if [ ! -f "$ZIP_PATH" ]; then
    "$DIALOG" --backtitle "$BACKTITLE" --title "Not Found" \
      --msgbox "File not found:\n$ZIP_PATH" 9 70
    return 1
  fi
  apt_ensure unzip
  USERS=$(getent passwd | awk -F: '/^user[0-9]+:/{print $1}')
  if [ -z "${USERS:-}" ]; then
    "$DIALOG" --backtitle "$BACKTITLE" --title "No Users" \
      --msgbox "No userX accounts found to deploy to." 8 50
    return 0
  fi
  for U in $USERS; do
    HOME_DIR=$(get_home "$U")
    [ -d "$HOME_DIR" ] || { log "Skip $U: no home dir"; continue; }
    DEST="$HOME_DIR/mfcourse"
    mkdir -p "$DEST"
    log "Unzipping $ZIP_PATH to $DEST for $U"
    unzip -o -q "$ZIP_PATH" -d "$DEST" >>"$LOG_FILE" 2>&1
    chown -R "$U:$U" "$DEST" 2>/dev/null || true
    chmod -R u+rwx "$DEST" 2>/dev/null || true
  done
  "$DIALOG" --backtitle "$BACKTITLE" --title "mfcourse.zip" \
    --msgbox "Deployed to ~/mfcourse for all userX accounts.\nIdempotent: contents overwritten in place." 10 70
}

# -------------------------------
# Package Installation (system-wide)
# -------------------------------
install_packages() {
  # Includes GUI tools you asked for
  apt_ensure nmap ncat x3270 firefox konsole terminator xterm
  "$DIALOG" --backtitle "$BACKTITLE" --title "Install Packages" \
    --msgbox "Installed:\n- nmap\n- ncat\n- x3270\n- firefox\n- konsole\n- terminator\n- xterm" 12 50
}

# -------------------------------
# Apply IceWM defaults to all userX
# -------------------------------
apply_icewm_to_all_users() {
  install_icewm_minimal
  USERS=$(getent passwd | awk -F: '/^user[0-9]+:/{print $1}')
  for U in $USERS; do configure_icewm_for_user "$U"; done
  "$DIALOG" --backtitle "$BACKTITLE" --title "IceWM" \
    --msgbox "Applied minimal IceWM to all userX accounts and /etc/skel." 9 70
}

# -------------------------------
# System-wide requirements.txt (Python 3.10.x)
# -------------------------------
install_requirements_system() {
  AUTODETECT=""
  USERS=$(getent passwd | awk -F: '/^user[0-9]+:/{print $1}')
  for U in $USERS; do CAND="$(get_home "$U")/mfcourse/requirements.txt"; [ -f "$CAND" ] && { AUTODETECT="$CAND"; break; }; done
  DEFAULT_REQ="${AUTODETECT:-$REQS_PATH_DEFAULT}"

  REQ_PATH=$("$DIALOG" --backtitle "$BACKTITLE" --title "Python requirements.txt (system-wide)" --stdout \
            --inputbox "Path to requirements.txt to install system-wide for Python 3.10.x:" 11 80 "$DEFAULT_REQ") || {
    log "Install requirements: cancelled"; return 0; }
  if [ ! -f "$REQ_PATH" ]; then
    "$DIALOG" --backtitle "$BACKTITLE" --title "Not Found" \
      --msgbox "File not found:\n$REQ_PATH" 9 70
    return 1
  fi

  apt_ensure python3 python3-pip python3-dev build-essential pkg-config
  PYV=$(python3 -V 2>&1 | awk '{print $2}')
  case "$PYV" in 3.10.*) : ;; *)
    "$DIALOG" --backtitle "$BACKTITLE" --title "Version Warning" --yesno \
      "Detected Python $PYV.\nYour tools target 3.10.x.\nProceed with system-wide install anyway?" 10 70 || {
      log "Aborted due to Python version mismatch ($PYV)"; return 1; } ;; esac

  BSP=""
  if python3 -m pip install --help 2>&1 | grep -q -- '--break-system-packages'; then BSP="--break-system-packages"; fi

  log "Upgrading pip (system-wide)"; python3 -m pip install -U pip $BSP >>"$LOG_FILE" 2>&1 || log "pip upgrade failed/skipped"
  log "Installing requirements from $REQ_PATH"; python3 -m pip install -U -r "$REQ_PATH" $BSP >>"$LOG_FILE" 2>&1

  "$DIALOG" --backtitle "$BACKTITLE" --title "requirements.txt" \
    --msgbox "Installed requirements system-wide for Python $(python3 -V | awk '{print $2}')." 8 70
}

# -------------------------------
# Tiny Web Server (Python http.server) on /srv via systemd
# -------------------------------
http_server_configure() {
  # Ask for port; default 8000
  PORT=$("$DIALOG" --backtitle "$BACKTITLE" --title "Configure Web Server" --stdout \
         --inputbox "Port for Python http.server (serving /srv):" 9 60 "8000") || { log "http: config cancelled"; return 0; }
  case "$PORT" in ''|*[!0-9]*|0) "$DIALOG" --backtitle "$BACKTITLE" --title "Invalid Port" --msgbox "Enter a valid TCP port (e.g., 8000)." 8 50; return 1;; esac
  apt_ensure python3
  mkdir -p /srv
  chown root:root /srv
  chmod 0755 /srv

  UNIT="/etc/systemd/system/mfcourse-http.service"
  log "Writing $UNIT (port $PORT)"
  cat > "$UNIT" <<EOF
[Unit]
Description=Python http.server serving /srv
After=network.target

[Service]
Type=simple
User=nobody
Group=nogroup
WorkingDirectory=/srv
ExecStart=/usr/bin/python3 -m http.server $PORT --directory /srv --bind 0.0.0.0
Restart=on-failure
Nice=10
ProtectSystem=full
ProtectHome=true
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
EOF

  systemctl daemon-reload >>"$LOG_FILE" 2>&1
  systemctl enable mfcourse-http.service >>"$LOG_FILE" 2>&1 || true

  # Open firewall if ufw is active
  if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
    ufw allow "$PORT"/tcp >>"$LOG_FILE" 2>&1 || true
  fi

  "$DIALOG" --backtitle "$BACKTITLE" --title "Web Server" \
    --msgbox "Configured Python http.server on port $PORT serving /srv as mfcourse-http.service.\nUse Start/Stop/Status from the menu." 11 70
}

http_server_start() {
  systemctl start mfcourse-http.service >>"$LOG_FILE" 2>&1 || true
  systemctl is-active --quiet mfcourse-http.service && MSG="Web server started." || MSG="Failed to start web server (see log)."
  "$DIALOG" --backtitle "$BACKTITLE" --title "Web Server" --msgbox "$MSG" 7 50
}

http_server_stop() {
  systemctl stop mfcourse-http.service >>"$LOG_FILE" 2>&1 || true
  "$DIALOG" --backtitle "$BACKTITLE" --title "Web Server" --msgbox "Web server stopped." 7 40
}

http_server_status() {
  TMP=$(mktemp); systemctl status --no-pager mfcourse-http.service >"$TMP" 2>&1 || true
  "$DIALOG" --backtitle "$BACKTITLE" --title "Web Server Status" --textbox "$TMP" 22 90
  rm -f "$TMP"
}

# -------------------------------
# Main Menu (dialog)
# -------------------------------
main_menu() {
  while :; do
    CHOICE=$("$DIALOG" --clear --backtitle "$BACKTITLE" --title "Main Menu" --stdout \
             --menu "Select an action" 22 82 14 \
             1 "Deploy Users (userX, default password + sudo)" \
             2 "Install Packages (nmap, ncat, x3270, firefox, konsole, terminator)" \
             3 "Configure XRDP & SSH (lean)" \
             4 "Deploy mfcourse.zip to all users" \
             5 "Apply minimal IceWM to all users" \
             6 "Install Python requirements.txt (system-wide)" \
             7 "Grant sudo to all userX accounts" \
             8 "Configure Web Server (/srv) -> set port & enable" \
             9 "Start Web Server" \
             10 "Stop Web Server" \
             11 "Web Server Status" \
             12 "Exit") || exit 0

    case "$CHOICE" in
      1) deploy_users ;;
      2) install_packages ;;
      3) configure_xrdp_ssh ;;
      4) deploy_mfcourse ;;
      5) apply_icewm_to_all_users ;;
      6) install_requirements_system ;;
      7) grant_sudo_all_userx ;;
      8) http_server_configure ;;
      9) http_server_start ;;
      10) http_server_stop ;;
      11) http_server_status ;;
      12) exit 0 ;;
      *) "$DIALOG" --backtitle "$BACKTITLE" --title "Unknown" --msgbox "Unrecognized option." 7 40 ;;
    esac
  done
}

# Entry
require_root
ensure_dialog
main_menu
