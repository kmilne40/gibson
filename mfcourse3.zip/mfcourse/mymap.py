#!/usr/bin/python 

from logging import config
import os
import subprocess
import time
import re
from tqdm import tqdm
from termcolor import colored
import json

from getters import get_scripts, get_port, get_target
from printers import print_menu, print_sub_menu, generate_report, view_output, print_script_description

last_command = ""

def read_config(option):
    with open('config.json', 'r') as config_file:
        config_data = json.load(config_file)

    return config_data["configuration"][option]

# Run the selected Nmap script
def run_script(script, target, port, output_file):
    global last_command
    if os.path.isfile(target):
        target_option = f"-iL {target}"  # Use -iL option for file input
        target = ""  # Clear the target since it's already included in target_option
    else:
        target_option = ""  # No option for IP address input
    if output_file:
        command = f" -T4 {port} {target_option} --script=/usr/share/nmap/scripts/{script} -oN {output_file} {target}"
        last_command = f"nmap -T4 {port} --script=/usr/share/nmap/scripts/{script} -oN {output_file}"
    else:
        command = f"nmap -T4 {port} {target_option} --script=/usr/share/nmap/scripts/{script} {target}"
        last_command = f" -T4 {port} --script=/usr/share/nmap/scripts/{script}"
    try:
        output = subprocess.check_output(command, shell=True)
        return output.decode()
    except subprocess.CalledProcessError as e:
        print(f"Error running script: {e}")
        last_command =""
        return None

#decide on output file
def get_output_file():
    output_ask = read_config('output_ask')
    output_default = read_config('output_default')

    if output_ask == "1":
        #if user wants asked about outputting to file
        while True:
            output_choice = input(colored("\nDo you want to output to file? (y/n): ", "yellow"))
            if output_choice.lower() == "y" or output_choice.lower() == "yes":
                output_file = input(colored("\nEnter output file (leave blank for default): ", "yellow"))
                if output_file.strip() == "":
                    timestr = time.strftime("%Y_%m_%d-%I_%M_%S_%p")
                    output_file = timestr + ".txt"
                    print(colored("\nDefault output file to be used: " + output_file, "green"))

                break
            elif output_choice.lower() == "n" or output_choice.lower() == "no":
                output_file = "" 
                break
            else:
                print(colored("Invalid option", "red"))
    else:
        #if user wants to use default option set in config
        if output_default == "1":
            output_file = input(colored("\nEnter output file (leave blank for default): ", "yellow"))
            if output_file.strip() == "":
                timestr = time.strftime("%Y_%m_%d-%I_%M_%S_%p")
                output_file = timestr + ".txt"
                print(colored("\nDefault output file to be used: " + output_file, "green"))
        else:
            output_file = ""   

    return output_file 

#decide on ouput being shown on screen
def get_screen_output(output):
    screen_output_ask = read_config('screen_output_ask')
    screen_output_default = read_config('screen_output_default')

    if screen_output_ask == 1:
        while True:
            view_choice = input(colored("\nDo you want to view the output? (y/n): ", "yellow"))
            if view_choice.lower() == "y" or view_choice.lower() == "yes":
                view_output(output)
                break
            elif view_choice.lower() == "n" or view_choice.lower() == "no":
                break
            else:
                print(colored("Invalid option", "red"))
    else:
        if screen_output_default == 1:
            view_output(output)
            view_choice = "y"

    return view_choice
    
#decide on report generation
def report_stuff(output, script, target, output_file, view_choice):
    report_ask = read_config('report_ask')
    report_default = read_config('report_default')
    

    if report_ask == 1:
        while True:
            report_choice = input(colored("Do you want to generate a penetration testing report? (y/n): ", "yellow"))
            if report_choice.lower() == "y" or report_choice.lower() == "yes":
                generate_report(output, script, target, output_file, view_choice)
                break
            elif report_choice.lower() == "n" or report_choice.lower() == "no":
                break
            else:
                print(colored("Invalid option", "red"))
    else:
        if report_default == 1:
            generate_report(output, script, target, output_file, view_choice)
            
               

def search(scripts):
    #get initial search and print results
    search_results = []
    while search_results == []:
        search_term = input(colored("\nEnter a search term (max 8 characters):\n-> ", 'yellow'))[:8]
        search_results = [script for category in scripts for script in scripts[category] if search_term in script]
        if search_results == []:
            print(colored('\nNO RESULTS', "red"))
    print_sub_menu("Search Results", search_results)

    #choose from sub menu
    script_choice = input(colored(f"\nChoose:\n- A script from Search Results by number.\n- 's' to go back to search again\n- '0' to go back to menu\n-> ", 'yellow'))
    
    while script_choice.lower() != 's' and (not script_choice.isdigit() or int(script_choice) < 0 or int(script_choice) > len(search_results)):
        print(colored("\nInvalid choice. Please try again.", "red"))
        script_choice = input(colored(f"\nENTER:\n- A script from Search Results by number.\n- 's' to go back to search again\n- '0' to go back to menu\n-> ", 'yellow'))
    
   
    if not script_choice.isdigit():
        if script_choice.lower() == 's':
                search(scripts)
    else: 
        script_choice = int(script_choice)
        if script_choice == 0:
            return
        else:
            #print info about option chosen
            print_script_description(search_results[script_choice-1])
            
            target = get_target()
            port = get_port()
            output_file = get_output_file()
            output = run_script(search_results[script_choice-1], target, port, output_file)
 
            if output:
                view_choice = get_screen_output(output)
                report_stuff(output, search_results[script_choice-1], target, output_file, view_choice)

            if read_config('speed_dial_ask') == 1:
                ask_to_add_to_speed_dial()

# Run a custom Nmap command
def run_custom_command():
    #show hints
    print(colored("\nExample: nmap <target> -p 80 -sV -O", "blue"))

    #ask user to enter custom nmap command
    command = input(colored("Enter your custom Nmap command:\n-> nmap ", "yellow"))

    # prevent command injection
    bad_chars = [';','&','>','|']
    if any([badchar in command for badchar in bad_chars]):
        print(f"Characters that could lead to command injection were found in the command, please do not use them")
        return None
    	
    output_file = get_output_file()

    if output_file:
        command += f" -oN {output_file}"

    try:
        output = subprocess.check_output("nmap " + command, shell=True)
    except subprocess.CalledProcessError as e:
        print(f"Error running command: {e}")
        return None

    output = output.decode()

    if output:
        view_choice = get_screen_output(output)
        report_stuff(output, command, "", output_file, view_choice)

    # add to speed dial for custom commands, attempts to extract the target from the command
    # might just not work, I'm not a great developer
    #if it is an IP address
        if re.search(r'((\d{1,2}|1\d{2}|2[0-4]\d|25[0-5])\.){3}(\d{1,2}|1\d{2}|2[0-4]\d|25[0-5])$', command):  
            
            remove_target= re.sub(r'((\d{1,2}|1\d{2}|2[0-4]\d|25[0-5])\.){3}(\d{1,2}|1\d{2}|2[0-4]\d|25[0-5])$','', command)
            ask_to_add_to_speed_dial(True,remove_target)
              
        else:
            print(colored("Cannot add this custom command to speed dial, as the target couldn't be removed, if you want, please add it manually", "yellow"))


def ask_to_add_to_speed_dial(custom=False,last=last_command):
    while True:
                if custom == True:
                    add_to_SD = input(colored("Do you want to add the last comamnd to speed dial? ONLY WORKS IF CUSTOM COMMAND USED AN IP AS A TARGET (y/n): ", "yellow"))
                else:
                    add_to_SD = input(colored("Do you want to add the last comamnd to speed dial? (y/n): ", "yellow"))
                if add_to_SD.lower() == "y" or add_to_SD.lower() == "yes":
                    print(f"adding {last_command} to speed dial")
                    title = input(colored("What do you want to name this scan in the speed dial?: ","yellow"))
                    #get previously saved dials
                    with open('config.json', 'r') as config_file:
                        config_data = json.load(config_file)
                    add_to_speed_dial(config_data,title,last_command)
                    break
                elif add_to_SD.lower() =="n" or add_to_SD.lower() == "no":
                    break
                else:
                    print(colored("Invalid option","red"))

def add_to_speed_dial(config,title,flags):
	config["speed_dial"][title] = flags
	
	with open('config.json','w') as config_file:
        	json.dump(config, config_file, indent=4)

#speed dial mode
def speed_dial():
    print("\nSPEED DIAL MENU")
    print("Add custom commands to speed dial for quick access.")

    while True:
        #get previously saved dials
        with open('config.json', 'r') as config_file:
            config_data = json.load(config_file)

        dials = config_data.get("speed_dial", {})

        titles = []
        content = []

        for key,value in dials.items():
            titles.append(key)
            content.append(key + ": " + value)
            

        if len(dials) == 0:
                #if there are none in file, tell user
                print(colored("\nYou have no speed dial options.", "red"))
        else:
            print_sub_menu("Saved", content)

        #get user option
            option = input(colored("\nENTER:\nNumber corresponding to speed dial\n'a' to add a speed dial\n'e' to erase a speed dial\n'0' to go back to main menu\n-> ", "yellow"))
            if option.lower() == "0":
                #go to main menu
                return
            elif option.lower() == "a":
                #add a dial
                while True:
                    #ask user for flags/options for the command
                    flags = input(colored("\nPlease enter the flags/options to be used\n e.g. -p 445 -v\nDo not include targets.\n-> ", "yellow"))
                    if flags != "" and not flags.isspace():
                        break
                
                while True:
                    #ask the user for a title for the command
                    title = input(colored("\nGive it a title:\n-> ", "yellow"))
                    if title != "" and not title.isspace() and title not in dials.keys():
                    	add_to_speed_dial(config_data,title,flags)
                    	break
                    else:
                        print(colored("Invalid Title", "red"))
                    
                #write to file

            elif option.lower() == "e":
                #delete a dial
                while True:
                    #ask user for the index of the dial they want to delete
                    to_delete = input(colored("\nEnter number of speed dial to delete\nEnter 0 to cancel\n-> ", "yellow"))
                    if to_delete == "0":
                        #cancel
                        break
                    elif to_delete.isdigit() and int(to_delete) < len(dials) + 1 and int(to_delete) > 0:
                        
                        del config_data["speed_dial"][titles[int(to_delete)-1]]

                        with open('config.json','w') as config_file:
                            json.dump(config_data, config_file, indent=4)
                        
                        
                        #tell user which one is deleted
                        print(colored("\nSpeed dial no. " + to_delete + " deleted.", "green"))
                        break
                    else:
                        print(colored("\nInvalid Option", "red"))
            elif option.isdigit() and int(option) < len(dials) + 1 and int(option) > 0:
                #they have chosen which dial they want to use

                #get target ip/file
                target = get_target()

                if os.path.isfile(target):
                    target_option = f"-iL "  # Use -iL option for file input
                else:
                    target_option = ""  # No option for IP address input

                #create command
                command = "nmap " + target_option + target + " " + dials[titles[int(option)-1]] 
    
                #sort if the output should be output to file
                output_file = get_output_file()

                if output_file:
                    command += f" -oN {output_file}"

                try:
                    output = subprocess.check_output(command, shell=True)
                except subprocess.CalledProcessError as e:
                    print(f"Error running command: {e}")
                    return None

                output = output.decode()

                if output:
                    #if there is output sort if it should be printed to screen and if a report should be generated
                    view_choice = get_screen_output(output)
                    report_stuff(output, command, "", output_file, view_choice)
            else:
                print(colored("\nInvalid Choice", "red"))

def config_checkup():
    while True:
        print("\nCURRENT CONFIGURATION")

        with open('config.json', 'r') as config_file:
            config_data = json.load(config_file)

        configuration = config_data.get("configuration", {})

        titles = []
        content = []

        for key,value in configuration.items():
            titles.append(key)
            content.append(key + ": " + str(value))

        print_sub_menu("Saved", content)

        option = input((colored("\nENTER:\n- Number of option to edit\n- '0' to go back\n-> ", 'yellow')))
        while not option.isdigit() or int(option) < 0 or int(option) > len(configuration):
            print(colored("\nInvalid Option", "red"))
            option = input((colored("\nENTER:\n- Number of option to edit\n- '0' to go back\n-> ", 'yellow')))

        if option == "0":
            #go to main menu
            return
        else:
            #wants to edit
            print("Editing " + titles[int(option)-1])
            new_value = input(colored("\nWhat value should it be set to? (1 or 0)\n-> ", "yellow"))
            while new_value != "0" and new_value != "1":
                print(colored("\nInvalid Option", "red"))
                new_value = input(colored("\nWhat value should it be set to? (1 or 0)\n-> ", "yellow"))

            config_data["configuration"][titles[int(option)-1]] = int(new_value)

            with open('config.json','w') as config_file:
                json.dump(config_data, config_file, indent=4)

            print(colored("\nConfig saved.", "green"))

def get_info_run_script(search_results,script):
    target = get_target()
    port = get_port()
    output_file = get_output_file()
    output = run_script(search_results[script-1], target, port, output_file)
 
    if output:
        view_choice = get_screen_output(output)
        report_stuff(output, search_results[script-1], target, output_file, view_choice)

        if read_config('speed_dial_ask') == 1:
            ask_to_add_to_speed_dial()

def choose_script_from_category(scripts,digit):
    if 1 <= digit <= len(scripts):
        category = list(scripts.keys())[digit-1]
        print_sub_menu(category, scripts[category])
        # print the scripts in the category and ask the user which one that want 
        script_choice = input(f"\nChoose a script from {category} category by number or '0' to go back: ")
        if int(script_choice) == 0:
            return
        elif not script_choice.isdigit() or int(script_choice) < 0 or int(script_choice) > len(scripts[category]):
            print("Invalid choice. Please try again.")
        get_info_run_script(scripts[category],int(script_choice))

#Main function
def main():
    print(colored("===============================\n      WELCOME TO... MYMAP!", "magenta"))
    print(colored("   A wrapper for nmap by Kev", "green"))
    print(colored("(modified by Sophie and Hubert)", "green"))
    print(colored("===============================", "magenta"))

    scripts = get_scripts()

    while True:
        #get user's decision
        print_sub_menu("SCRIPT CATEGORIES", list(scripts.keys())[:10])
        category_choice = input((colored("\nOR ENTER:\n- number of script category\n- 's' to search\n- 'c' to custom command\n- 'd' to speed dial\n- 'e' to edit settings\n- 'q' to quit\n-> ", 'yellow')))

        match category_choice.lower():
            case 'q':
                # exit, see you around space cowboy
                break
            case 's':
                #search for scripts using their name
                search(scripts)
            case 'c':
                # input and run a custom command (pretty much pastes what you enter here in front of 'nmap' in the cli)
                run_custom_command()
            case 'd':
                # enter the speed dial menu
                speed_dial()
            case 'e':
                # edit the config (I think it might mess up a bit)
                config_checkup()
            case default:
                # none of the letters were entered, if a number was entered browse the categories
                if category_choice.isdigit() == True:
                    choose_script_from_category(scripts,int(category_choice))
                else:
                    print(colored("\nInvalid Option!","red")) 

            

    print(colored("\nCheerio! And Kev was on his way!", "green"))

if __name__ == "__main__":
    main()
