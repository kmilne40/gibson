import scapy.all as scapy
import ebcdic
from scapy.sessions import TCPSession
from tabulate import tabulate

def analyze_pcap(file_path,encoding_choice):
    try:
        packets = scapy.sniff(offline=file_path, session=TCPSession)
    except FileNotFoundError:
        return f"Error: File not found at {file_path}. Please check the path and try again."
    except Exception as e:
        return f"Error: {str(e)}"

    session_details = {}

    for packet in packets:
        if packet.haslayer(scapy.IP) and packet.haslayer(scapy.TCP):
            src_ip = packet[scapy.IP].src
            dst_ip = packet[scapy.IP].dst
            src_port = packet[scapy.TCP].sport
            dst_port = packet[scapy.TCP].dport
            session_key = f"{src_ip}:{src_port}-{dst_ip}:{dst_port}"

            direction = 'response' if src_port < dst_port else 'command'
            if session_key not in session_details:
                session_details[session_key] = {
                    'source_ip': src_ip, 'source_port': src_port,
                    'destination_ip': dst_ip, 'destination_port': dst_port,
                    'packets': 0,
                    'transactions': []
                }
            if encoding_choice == 'y' or encoding_choice == 'Y':
                payload = bytes(packet[scapy.TCP].payload).decode('cp1146', errors='ignore') if packet[scapy.TCP].payload else ""
            else:
                payload = bytes(packet[scapy.TCP].payload).decode('utf-8', errors='ignore') if packet[scapy.TCP].payload else ""
            
            if payload:
                if direction == 'command':
                    session_details[session_key]['transactions'].append({'command': payload, 'response': ''})
                else:
                    if session_details[session_key]['transactions'] and session_details[session_key]['transactions'][-1]['response'] == '':
                        session_details[session_key]['transactions'][-1]['response'] = payload
                    else:
                        session_details[session_key]['transactions'].append({'command': '', 'response': payload})

            session_details[session_key]['packets'] += 1

    return session_details

def format_session_data(sessions):
    formatted_data = []
    for session, details in sessions.items():
        for transaction in details['transactions']:
            formatted_data.append([
                session,
                details['source_ip'],
                details['source_port'],
                details['destination_ip'],
                details['destination_port'],
                details['packets'],
                transaction['command'],
                transaction['response']
            ])
    return formatted_data

def main():
    file_path = input("Please enter the path to the .pcap file to be analyzed: ")
    encoding_choice = input("Do you want to decode supplied .pcap file using EBCDIC (y/n)?: ")
    sessions = analyze_pcap(file_path,encoding_choice)
    if isinstance(sessions, str):
        print(sessions)
    else:
        formatted_data = format_session_data(sessions)
        print(tabulate(formatted_data, headers=['Session', 'Source IP', 'Source Port', 'Destination IP', 'Destination Port', 'Packets', 'Command', 'Response'], tablefmt='grid'))

if __name__ == "__main__":
    main()