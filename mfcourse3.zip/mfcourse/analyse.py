import argparse
import re
from scapy.layers.l2 import Ether
import scapy.all as scapy
from scapy.utils import wrpcap

def get_default_iface_name_linux():
    with open("/proc/net/route") as f:
        for line in f.readlines():
            try:
                iface, dest, _, flags, _, _, _, _, _, _, _, =  line.strip().split()
                if dest != '00000000' or not int(flags, 16) & 2:
                    continue
                return iface
            except:
                continue

class Port(int):
    """
    A Network Port (i.e., 0 < integer <= 65535)
    """
    def __new__(cls, val, *args, **kwargs):
        newInt = int.__new__(cls, val, *args, **kwargs)
        if not 0 < newInt <= 65535:
            raise ValueError("Port out of range")
        return newInt


USER_INPUT_REGEX = re.compile(b"\x7d..\x11..(.*)\x40*\xff\xef$")



def sniff_and_write_packet(ip_address, port, interface):
    # Create filter for capturing packets
    filter_str = f"dst {ip_address} and port {port} and tcp"

    # Define the packet capture callback function
    def packet_callback(packet: Ether):
        rawData = bytes(packet[scapy.TCP])
        if (m := re.search(USER_INPUT_REGEX, rawData)):
            print(m.group(1).decode('cp500'))
    

    # Start sniffing packets
    print(f"Starting Packet Capture on {interface}: Use Ctrl + C to exit")
    scapy_kwargs = {"filter": filter_str, "prn": packet_callback}
    packets = scapy.sniff(**scapy_kwargs, iface=interface)
    # packets = scapy.sniff(**scapy_kwargs, iface="lo")

    # Write captured packets to a pcap file
    wrpcap('EBC.pcap', packets)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="EBCDIC Packet Sniffer")
    parser.add_argument("TARGET", help="Target for traffic sniffing")
    parser.add_argument("-p", "--port", help="Target port (Default: 3270)", default=3270, type=Port)
    parser.add_argument("-i","--iface", help="Interface to use (defaults to default gateway interface)", default=get_default_iface_name_linux())
    args = parser.parse_args()


  
    # Sniff packets and write to pcap file
    sniff_and_write_packet(args.TARGET, args.port, args.iface)

