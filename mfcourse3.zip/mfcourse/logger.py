import sys
import os
import threading

class Logger:
    def __init__(self, filename):
        self.terminal = sys.stdout
        self.log = open(filename, 'a')

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)
        self.log.flush()

    def flush(self):
        pass

class InputLogger:
    def __init__(self, filename):
        self.terminal = sys.stdin
        self.log = open(filename, 'a')

    def readline(self):
        input_line = self.terminal.readline()
        self.log.write(input_line)
        self.log.flush()
        return input_line

class InteractiveSession:
    def __init__(self, log_filename):
        self.log_filename = log_filename
        self.logging = False

    def start_logging(self):
        self.logging = True
        sys.stdout = Logger(self.log_filename)
        sys.stdin = InputLogger(self.log_filename)
        print("Logging started...")

    def stop_logging(self):
        if self.logging:
            self.logging = False
            sys.stdout = sys.__stdout__
            sys.stdin = sys.__stdin__
            print("Logging stopped...")

    def run(self):
        print("Enter 'start' to begin logging, 'stop' to end logging, and 'exit' to quit.")
        while True:
            user_input = input("Command: ").strip().lower()
            if user_input == 'start':
                self.start_logging()
            elif user_input == 'stop':
                self.stop_logging()
            elif user_input == 'exit':
                self.stop_logging()
                break
            else:
                print(f"Unknown command: {user_input}")

if __name__ == "__main__":
    log_filename = "session_log.txt"
    
    # Check if the logfile exists and create if not
    if not os.path.exists(log_filename):
        with open(log_filename, 'w') as f:
            pass

    session = InteractiveSession(log_filename)
    session.run()
