
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ebs_check.py — Interactive, SAFE exposure precheck for Oracle E-Business Suite (CVE-2025-61882 context).

Features:
  • Input menu: prompts for hosts file & port (80/443) if not supplied via args.
  • Live updates: prints current endpoint under test and overall percentage.
  • Final table: Domain | Checked | Vuln (✔/✘) | Why (e.g., ENDPOINT ACCESSIBLE, AUTH REQUIRED, BLOCKED/WAF, NO ISSUE)
  • Non-exploitative: GET only; no payloads or POSTs.

Usage (optional flags; prompts appear if omitted):
  python ebs_check.py --hosts hosts.txt --port 443 --timeout 10 --insecure

Dependencies: requests
  pip install requests
"""
import argparse
import sys
from typing import List, Tuple, Dict
from urllib.parse import urlparse, urlunparse, urljoin

try:
    import requests
except Exception:
    print("[!] This script requires 'requests'. Install it with: pip install requests", file=sys.stderr)
    raise

DEFAULT_HEADERS = {"User-Agent": "ebs-check/1.2 (+authorized testing)"}

ENDPOINTS = [
    "/OA_HTML/AppsLogin",
    "/OA_HTML/configurator/UiServlet",
    "/OA_HTML/SyncServlet",
    "/OA_HTML/OA.jsp?page=/oracle/apps/xdo/oa/template/webui/TemplatePreviewPG",
]

FINGERPRINT_STRINGS = [
    "Oracle E-Business Suite",
    "OA.jsp",
    "E-Business Suite",
    "AppsLogin",
    "SyncServlet",
    "UiServlet",
    "XDO",
]

def load_lines(path: str) -> List[str]:
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return [ln.strip() for ln in f if ln.strip() and not ln.strip().startswith("#")]

def build_base_url(host_entry: str, chosen_port: int) -> str:
    host_entry = host_entry.strip()
    if not host_entry:
        raise ValueError("Empty host entry")
    parsed = urlparse(host_entry if "://" in host_entry else f"//{host_entry}", scheme="")
    scheme = parsed.scheme
    netloc = parsed.netloc or parsed.path
    host = netloc.split("/", 1)[0]
    # Explicit port?
    if ":" in host:
        hostname, port_s = host.split(":", 1)
        try:
            port = int(port_s)
        except ValueError:
            port = chosen_port
        host = f"{hostname}:{port}"
        if not scheme:
            scheme = "https" if port == 443 else "http"
    else:
        port = chosen_port
        if not scheme:
            scheme = "https" if chosen_port == 443 else "http"
        default_port = 443 if scheme == "https" else 80
        host = (netloc if port == default_port else f"{netloc}:{port}")
    return urlunparse((scheme, host, "", "", "", ""))

def prompt_menu() -> Tuple[str, int, float, bool]:
    print("=== EBS Exposure Precheck (SAFE) ===")
    hosts = input("Enter path to hosts file (one host/URL per line): ").strip()
    while True:
        port_in = input("Choose port [80 or 443]: ").strip()
        if port_in in {"80", "443"}:
            port = int(port_in); break
        print("Please enter 80 or 443.")
    timeout_in = input("HTTP timeout seconds [default 10]: ").strip() or "10"
    try:
        timeout = float(timeout_in)
    except ValueError:
        timeout = 10.0
    insecure_in = input("Disable TLS verification? (y/N): ").strip().lower()
    insecure = insecure_in == "y"
    return hosts, port, timeout, insecure

def scan_host(sess: requests.Session, base_url: str, timeout: float, overall_idx: int, overall_total: int) -> Dict[str, str]:
    """
    Returns a summary dict with keys: domain, checked, vuln, why
    Heuristics:
      - 200/301/302 + EBS fingerprint -> potential exposure (✔ ENDPOINT ACCESSIBLE)
      - 401 + fingerprint -> ✘ AUTH REQUIRED
      - 403/406/429 -> ✘ BLOCKED/WAF (if nothing else hit)
      - only errors/timeouts/404 -> ✘ NO ISSUE
    """
    seen_accessible = False
    seen_auth = False
    seen_block = False
    seen_error = False

    parsed = urlparse(base_url)
    domain = parsed.netloc

    total_eps = len(ENDPOINTS)
    for idx, ep in enumerate(ENDPOINTS, 1):
        url = urljoin(base_url + "/", ep.lstrip("/"))
        try:
            r = sess.get(url, timeout=timeout, allow_redirects=True)
            status = r.status_code
            text = r.text or ""
            lc = text.lower()
            fp = any(s.lower() in lc for s in FINGERPRINT_STRINGS)

            # Live per-host update
            host_pct = (idx / total_eps) * 100.0
            overall_pct = ((overall_idx - 1) * total_eps + idx) / (overall_total * total_eps) * 100.0
            print(f"[{overall_pct:5.1f}%] {domain:40} {status:3}  {ep}")

            if status in (200, 301, 302) and fp:
                seen_accessible = True
            elif status == 401 and fp:
                seen_auth = True
            elif status in (403, 406, 429):
                seen_block = True
            elif status >= 500:
                seen_error = True
        except requests.exceptions.SSLError:
            print(f"[WARN] SSL error: {domain} {ep}")
            seen_error = True
        except requests.exceptions.Timeout:
            print(f"[WARN] Timeout: {domain} {ep}")
            seen_error = True
        except requests.exceptions.ConnectionError:
            print(f"[WARN] Connection error: {domain} {ep}")
            seen_error = True
        except Exception as e:
            print(f"[WARN] Error: {domain} {ep} -> {e}")
            seen_error = True

    if seen_accessible:
        vuln = "✔"; why = "ENDPOINT ACCESSIBLE"
    elif seen_auth and not seen_accessible:
        vuln = "✘"; why = "AUTH REQUIRED"
    elif seen_block and not (seen_accessible or seen_auth):
        vuln = "✘"; why = "BLOCKED/WAF"
    elif seen_error:
        vuln = "✘"; why = "ERRORS/NO RESPONSE"
    else:
        vuln = "✘"; why = "NO ISSUE"

    return {"domain": domain, "checked": "Yes", "vuln": vuln, "why": why}

def format_table(rows: List[Dict[str, str]]) -> str:
    headers = ["Domain", "Checked", "Vuln", "Why"]
    # Calculate widths
    w_domain = max(len(r["domain"]) for r in rows + [{"domain": headers[0]}])
    w_checked = len(headers[1])
    w_vuln = len(headers[2])
    w_why = max(len(r["why"]) for r in rows + [{"why": headers[3]}])
    col_widths = [w_domain, w_checked, w_vuln, w_why]

    line = "+-" + "-+-".join("-"*w for w in col_widths) + "-+"
    def fmt_row(vals):
        return "| " + " | ".join(f"{v:<{w}}" for v, w in zip(vals, col_widths)) + " |"

    out = [line, fmt_row(headers), line]
    for r in rows:
        out.append(fmt_row([r["domain"], r["checked"], r["vuln"], r["why"]]))
    out.append(line)
    return "\n".join(out)

def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("--hosts")
    ap.add_argument("--port", type=int, choices=[80, 443])
    ap.add_argument("--timeout", type=float, default=10.0)
    ap.add_argument("--insecure", action="store_true")
    args, _ = ap.parse_known_args()

    if not args.hosts or not args.port:
        hosts_file, port, timeout, insecure = prompt_menu()
    else:
        hosts_file, port, timeout, insecure = args.hosts, args.port, args.timeout, args.insecure

    try:
        hosts_list = load_lines(hosts_file)
    except Exception as e:
        print(f"[!] Could not read hosts file: {e}", file=sys.stderr)
        sys.exit(2)

    # Build base URLs
    base_urls = []
    for h in hosts_list:
        try:
            base_urls.append(build_base_url(h, port))
        except Exception as e:
            print(f"[!] Skipping host '{h}': {e}", file=sys.stderr)

    if not base_urls:
        print("[!] No valid hosts to test.", file=sys.stderr)
        sys.exit(2)

    sess = requests.Session()
    sess.headers.update(DEFAULT_HEADERS)
    sess.verify = not (args.insecure if args.hosts and args.port else insecure)

    total_hosts = len(base_urls)
    print(f"\nPlanned: {total_hosts} host(s) × {len(ENDPOINTS)} endpoints = {total_hosts*len(ENDPOINTS)} requests\n")

    results = []
    for i, base in enumerate(base_urls, 1):
        res = scan_host(sess, base, (args.timeout if args.hosts and args.port else timeout), i, total_hosts)
        results.append(res)

    print("\n=== Summary ===")
    print(format_table(results))
    print("\nLegend: Vuln=✔ means EBS endpoint appears accessible with fingerprints (potential exposure).")
    print("        Vuln=✘ means auth/WAF/no issue/errors observed with these SAFE checks.\n")

if __name__ == "__main__":
    main()
