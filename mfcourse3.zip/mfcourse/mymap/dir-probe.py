
#!/usr/bin/env python3
"""
dir_probe.py — Enumerate whether directories exist on one or more web servers,
and report any files visible via directory listings (auto-index pages).

USAGE (examples):
  python dir_probe.py --dirs dirs.txt --hosts hosts.txt --port 443 --threads 15 --out results.csv
  python dir_probe.py --dirs dirs.txt --hosts hosts.txt --port 80  --insecure

INPUT FILES:
  - dirs.txt  : one directory path per line (e.g., /admin, /backup/, static)
  - hosts.txt : one host or URL per line (e.g., example.com, https://app.example.com)

NOTES:
  - Only use on systems you own or have explicit permission to test.
  - "Exists" includes HTTP 200/301/302/401/403 (present but protected or redirected).
  - Files are reported only when a visible directory listing (e.g., Apache/Nginx autoindex) is detected.

Requires: requests, beautifulsoup4 (optional for better parsing)
    pip install requests beautifulsoup4
"""
import argparse
import concurrent.futures as cf
import csv
import html
import re
import sys
import time
from dataclasses import dataclass
from typing import List, Optional, Tuple
from urllib.parse import urlparse, urlunparse, urljoin

# Optional imports
try:
    import requests
except Exception as e:
    print("[!] requests is required: pip install requests", file=sys.stderr)
    raise

try:
    from bs4 import BeautifulSoup
    HAVE_BS4 = True
except Exception:
    HAVE_BS4 = False

DEFAULT_HEADERS = {
    "User-Agent": "dir-probe/1.1 (+authorized testing)"
}

EXISTENCE_STATUSES = {200, 301, 302, 401, 403, 405}

@dataclass
class ProbeResult:
    host: str
    port: int
    directory: str
    url: str
    status: Optional[int]
    exists: bool
    redirected_to: Optional[str]
    files: List[str]
    error: Optional[str]
    content_type: Optional[str]

def normalize_dir_path(p: str) -> str:
    p = p.strip()
    if not p:
        return ""
    if not p.startswith("/"):
        p = "/" + p
    if not p.endswith("/"):
        p = p + "/"
    return p

def build_base_url(host_entry: str, chosen_port: int) -> Tuple[str, int]:
    host_entry = host_entry.strip()
    if not host_entry:
        raise ValueError("Empty host entry")
    parsed = urlparse(host_entry if "://" in host_entry else f"//{host_entry}", scheme="")
    scheme = parsed.scheme
    netloc = parsed.netloc or parsed.path
    hostname = netloc.split("/", 1)[0]
    port = None
    if ":" in hostname:
        base_host, explicit_port = hostname.split(":", 1)
        hostname = base_host
        try:
            port = int(explicit_port)
        except ValueError:
            port = chosen_port
    if port is None:
        port = chosen_port
    if not scheme:
        scheme = "https" if port == 443 else "http"
    default_port = 443 if scheme == "https" else 80
    netloc_final = hostname if port == default_port else f"{hostname}:{port}"
    base_url = urlunparse((scheme, netloc_final, "", "", "", ""))
    return base_url, port

def parse_listing(html_text: str) -> List[str]:
    files = []
    text_lc = html_text.lower()
    autoindex_signals = [
        "index of /", "directory listing for", "nginx autoindex", "apache server at", "parent directory"
    ]
    if any(sig in text_lc for sig in autoindex_signals):
        if HAVE_BS4:
            soup = BeautifulSoup(html_text, "html.parser")
            for a in soup.find_all("a", href=True):
                name = a.get_text(strip=True) or a["href"]
                href = a["href"]
                if name.lower() in {"parent directory", "up to higher level directory"}:
                    continue
                if href.startswith("#"):
                    continue
                name = name.strip().strip("/")
                if name:
                    files.append(name)
        else:
            for m in re.finditer(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', html_text, re.IGNORECASE|re.DOTALL):
                href = m.group(1)
                label = re.sub("<[^<]+?>", "", m.group(2)).strip()
                item = (label or href).strip("/")
                if item.lower() == "parent directory":
                    continue
                if item and item not in files:
                    files.append(item)
    return files

def probe_one(session, base_url: str, port: int, directory: str, timeout: float):
    url = urljoin(base_url + "/", directory.lstrip("/"))
    redirected_to = None
    files = []
    status = None
    ctype = None
    try:
        resp = session.get(url, allow_redirects=True, timeout=timeout)
        status = resp.status_code
        ctype = resp.headers.get("Content-Type", "")
        final_url = str(resp.url)
        if final_url != url:
            redirected_to = final_url
        exists = status in EXISTENCE_STATUSES
        if exists and "text/html" in (ctype or "").lower() and resp.text:
            files = parse_listing(resp.text)
        return {
            "host": base_url,
            "port": port,
            "directory": directory,
            "url": final_url,
            "status": status,
            "exists": exists,
            "redirected_to": redirected_to,
            "files": files,
            "error": None,
            "content_type": ctype,
        }
    except Exception as e:
        return {
            "host": base_url,
            "port": port,
            "directory": directory,
            "url": url,
            "status": status,
            "exists": False,
            "redirected_to": None,
            "files": [],
            "error": str(e),
            "content_type": ctype,
        }

def load_lines(path: str):
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return [ln.strip() for ln in f if ln.strip() and not ln.strip().startswith("#")]

def main():
    import requests
    ap = argparse.ArgumentParser(description="Probe whether directories exist on web servers and list visible files.")
    ap.add_argument("--dirs", required=True, help="Path to file containing directory paths (one per line)")
    ap.add_argument("--hosts", required=True, help="Path to file containing hosts or base URLs (one per line)")
    ap.add_argument("--port", type=int, choices=[80, 443], default=443, help="Port/scheme to use when not specified in hosts")
    ap.add_argument("--timeout", type=float, default=10.0, help="Request timeout in seconds")
    ap.add_argument("--threads", type=int, default=12, help="Concurrency level")
    ap.add_argument("--insecure", action="store_true", help="Disable TLS verification (NOT recommended)")
    ap.add_argument("--out", default="dir_probe_results.csv", help="Output CSV path")
    args = ap.parse_args()

    dirs = [normalize_dir_path(d) for d in load_lines(args.dirs)]
    hosts_raw = load_lines(args.hosts)

    bases = []
    for h in hosts_raw:
        try:
            base_url, eff_port = build_base_url(h, args.port)
            bases.append((base_url, eff_port))
        except Exception as e:
            print(f"[!] Skipping host entry '{h}': {e}", file=sys.stderr)

    if not dirs or not bases:
        print("[!] No valid directories or hosts to probe.", file=sys.stderr)
        sys.exit(2)

    sess = requests.Session()
    sess.headers.update(DEFAULT_HEADERS)
    sess.verify = not args.insecure

    results = []
    tasks = []
    with cf.ThreadPoolExecutor(max_workers=max(1, args.threads)) as ex:
        for base_url, port in bases:
            for d in dirs:
                tasks.append(ex.submit(probe_one, sess, base_url, port, d, args.timeout))
        for fut in cf.as_completed(tasks):
            results.append(fut.result())

    # Pretty print
    from collections import defaultdict
    print("\n=== Directory Probe Summary ===")
    by_host = defaultdict(list)
    for r in results:
        by_host[(r["host"], r["port"])].append(r)
    for (host, port), items in by_host.items():
        print(f"\nHost: {host}  (port {port})")
        for r in sorted(items, key=lambda x: x["directory"]):
            status = r["status"] if r["status"] is not None else "-"
            exists = "YES" if r["exists"] else "NO"
            note = ""
            if r["redirected_to"] and r["redirected_to"] != r["url"]:
                note = f"→ {r['redirected_to']}"
            elif r["redirected_to"] and r["redirected_to"] == r["url"]:
                note = f"→ redirect"
            if r["error"]:
                note = f"ERR: {r['error']}"
            files_info = f"{len(r['files'])} file(s)" if r["files"] else ""
            print(f"  {r['directory']:30}  {status:>3}  exists={exists:3}  {files_info:10}  {note}")

    # CSV
    with open(args.out, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["host", "port", "directory", "final_url", "status", "exists", "files_found", "file_list", "content_type", "error"])
        for r in results:
            w.writerow([
                r["host"], r["port"], r["directory"], r["url"], r["status"] or "",
                r["exists"], len(r["files"]), ";".join(r["files"][:50]), r["content_type"] or "", r["error"] or ""
            ])
    print(f"\n[+] CSV written: {args.out}")

if __name__ == "__main__":
    main()
