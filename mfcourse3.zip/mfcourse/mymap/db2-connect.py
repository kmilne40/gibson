#!/usr/bin/env python3
import asyncio
import websockets
import sys

async def interact(host, username, password):
    uri = f"ws://{host}:50001"
    try:
        async with websockets.connect(uri) as websocket:
            print(f"Connected to {uri}\n")

            # Receive greeting
            greeting = await websocket.recv()
            print(greeting.strip())

            # Send LOGIN
            login_cmd = f"LOGIN {username} {password}"
            print(f">>> {login_cmd}")
            await websocket.send(login_cmd)

            # Receive login response
            login_response = await websocket.recv()
            print(login_response.strip())

            if "Login successful" not in login_response:
                print("❌ Login failed.")
                return

            print("✅ Logged in. Type commands (or Ctrl+C to exit):\n")

            # Interactive loop
            while True:
                try:
                    cmd = input(">>> ")
                    await websocket.send(cmd)
                    response = await websocket.recv()
                    print(response.strip())
                except KeyboardInterrupt:
                    print("\nExiting.")
                    break
    except Exception as e:
        print(f"❌ Connection failed: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: ./db2ws_connect.py <host> <username> <password>")
    else:
        asyncio.run(interact(sys.argv[1], sys.argv[2], sys.argv[3]))
